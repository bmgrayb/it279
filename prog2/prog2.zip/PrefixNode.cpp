/*ULID: bmgrayb
 *Programmer: Brandon Graybeal
 *Date: 2/18/2014
 *This program represents one node of this data structure
 */

#include <vector>
#include <string>
#include "PrefixNode.h"
using namespace std;

PrefixNode::PrefixNode()
{
  int i;
  for(i =0; i < 26; i++)
  {
    this->nodeList[i] = NULL;
  }


}

PrefixNode::~PrefixNode()
{
  //delete[] nodeList;
  words.clear();
}
